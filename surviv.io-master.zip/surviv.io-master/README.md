# Surviv.io Hacks & Stuff
Pretty inactive. But, eh, maybe I will do something.

## MegaMod?
**Not making this anymore. Thanks for 1,338 (Yeah I found the real number) users**
