# I AM NOT MAKING THIS ANYMORE SINCE SURVIV PATCHED IT FOR 75% OF USERS. THANKS FOR 1000+ USERS.

# MegaMod (Log & Load)
This update has everything it had before but it works with the Surviv.io "Suns out, Guns out" update. I still plan to add...

* Aimbot
* Increasable zoom
* Autoloot (working on right now)

## Installation:
1. Install the [Resource Override](https://chrome.google.com/webstore/detail/resource-override/pkoacgokdfckfpndoffpifphamojphii) extension for Google Chrome.
2. Go to the Resource Override settings and fill in the following settings:\
Tab URL:  `*surviv.io*`\
From:  `http://surviv.io/js/app.*.js` To:`https://rawgit.com/IceHacks/surviv.io/master/megamod/app.js`
3. Add another with these:\
From:  `http://surviv.io/js/manifest.*.js` To:`https://rawgit.com/IceHacks/surviv.io/master/megamod/manifest.js`
4. Add another with these:\
From:  `http://surviv.io/js/vendor.*.js` To:`https://rawgit.com/IceHacks/surviv.io/master/megamod/vendor.js`
5. Go to [surviv.io](http://surviv.io/) and hit `CTRL` + `F5`

(this works only on Chrome, if you want it for another browser ask for the instructions in an issue)

## Features:
* No roofs or ceilings
* Transparent trees, bushes and tables
* Transparent smoke grenades
* Slightly bigger zoom
* Automatically pick-up loot (<a href="#addons">addon</a>)

## Addons:

All addons are UserScripts that are installed separately.

* MegaPack (Autoloot + more soon) | `addon/megamod.user.js`

Hope you enjoy,
IceHacks

TIP: If you love this I could use some cash: https://paypal.me/pools/c/85EKjp6vaJ
